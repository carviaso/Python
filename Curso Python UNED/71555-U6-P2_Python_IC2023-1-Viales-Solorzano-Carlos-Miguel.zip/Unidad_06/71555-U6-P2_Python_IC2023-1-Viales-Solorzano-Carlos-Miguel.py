from Vuelos import Vuelos

vuelos = []


def lista_vuelos():
    for vuelo in vuelos:
        costo_combustible = vuelo.calcular_costo_combustible()
        print(f"Vuelo {vuelo.num_vuelo}: {costo_combustible} colones")


while True:
    print("----- Menú -----")
    print("1. Registrar vuelo")
    print("2. Lista Vuelos")
    print("3. Salir")

    opcion = input("Seleccione una opción: ")

    if opcion == "1":
        num_vuelo = input("Número de vuelo: ")
        ciudad_origen = input("Ciudad origen: ")
        ciudad_destino = input("Ciudad destino: ")
        compania = input("Compañía aérea: ")
        tipo_aeronave = input("Tipo de aeronave: ")
        km = float(input("Kilometraje entre punto de inicio y de fin: "))

        vuelo = Vuelos(num_vuelo, ciudad_origen, ciudad_destino, compania, tipo_aeronave, km)
        vuelos.append(vuelo)
        print("Vuelo registrado exitosamente.")
    elif opcion == "2":
        lista_vuelos()
    elif opcion == "3":
        break
    else:
        print("Opción inválida.")

print("Gracias por usar el sistema.")