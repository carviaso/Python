from persona import Persona

class Estudiante (Persona):
    carnet = ''
    carrera = ''



