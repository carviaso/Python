from animal import Animal

class Gato (Animal):
    def mostrarSonido(self):
        return "miau"

    def mostrarAlimentacion(self):
        return "ratones"

    