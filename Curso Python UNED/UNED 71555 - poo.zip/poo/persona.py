class Persona:
    cedula = ''
    nombre = ''
    apellidos = ''
    edad = 0

    