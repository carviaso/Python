class Animal:

    def mostrarSonido(self):
        return "La mayoria de animales emite sonido"

    def mostrarAlimentacion(self):
        return "La alimentacion varía entre animales"


    