class Edificio:
    _pisos = 0;
    areaDePiso = 0

    def _calcularAreaTotal(self):
        return self.areaDePiso * self._pisos


