from animal import Animal

class Jirafa (Animal):
    def mostrarSonido(self):
        return "No tengo sonido"

    def mostrarAlimentacion(self):
        return "Hojas"