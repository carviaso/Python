from persona import Persona

class Profesor (Persona):
    catedra = ''
    curso = ''


